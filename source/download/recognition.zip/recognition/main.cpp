#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

//滚动条回掉函数
void Callback(int, void*);

//窗口名和原图地址
const char* WIN_SRC = "Src win";
const char* WIN_DST = "Dst win";
const char* SRC_PATH = "./pic/1-1.jpg";

//滚动条数值初始化
int thresValue = 64;
int param_1 = 100;
int param_2 = 100;
int rectValue = 20;
auto cirNum = 1;

//全局变量
Mat src;
Mat dst;
Mat thresPic;
vector<Vec3f> circles;
vector< vector<Point> > contours;
vector<Vec4i> info;
char buffer[16] = {0};

//标准灰度值
static int standVal = 60;

int main()
{  
    //变量初始化
    int avgVal;
    int value = 0;
    int count = 0;
    //创建窗口
    namedWindow(WIN_SRC, 0);
    namedWindow(WIN_DST, 0);

    //载入原图
    src = imread(SRC_PATH);

    //将原图格式转化为灰度图格式
    cvtColor(src, dst, CV_BGR2GRAY);

    //创建滚动条
    createTrackbar("thres:", WIN_DST, &thresValue, 255, Callback);
    createTrackbar("param_1:", WIN_DST, &param_1, 500, Callback);
    createTrackbar("param_2:", WIN_DST, &param_2, 500, Callback);
    createTrackbar("rectValue:", WIN_DST, &rectValue, 50, Callback);
    createTrackbar("cirNum:", WIN_DST, &cirNum, 10, Callback);

    //二值化图像
    threshold(dst, thresPic, thresValue, 255, CV_THRESH_BINARY);
    //medianBlur();
    //高斯滤波
    GaussianBlur(thresPic, thresPic, Size(9,9), 0, 0);

    findContours(thresPic, contours, info, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);

    for(size_t i = 0; i < contours.size(); i++)
    {
        if(fabs(contourArea(contours[i])) > 2000)
            drawContours(src, contours, i, Scalar(0, 255, 0), 2);
    }

    //霍夫圆检测
    HoughCircles(thresPic, circles, CV_HOUGH_GRADIENT, 1, 10, param_2, param_1);

    //画出圆心和圆
    for(size_t i = 0; i < circles.size(); i++)
    {
        Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
        int radius = cvRound(circles[i][2]);

        circle(src, center, 1, Scalar(0,255,0), -1);
        circle(src, center, radius, Scalar(0,0,255), 3);

        //定义标准矩形区域
        Point p1(center.x-rectValue, center.y-rectValue);
        Point p2(center.x+rectValue, center.y+rectValue);
        rectangle(src, p1, p2, Scalar(255,255,0), 1);
        //显示数字
        sprintf(buffer, "%d", i+1);
        putText(src, buffer, p2, FONT_HERSHEY_PLAIN, 1, Scalar(255, 0, 0));

        //求得该区域的平均灰度值
        for(int i = p1.x; i < p2.x; i++)
        {
            for(int j = p1.y; j < p2.y; j++)
            {
                value += dst.at<uchar>(j, i);
                count++;
            }
        }

        cout<<"=================================="<<endl;

        //cout<<"center:"<<center<<endl;
        cout<<"Circle-Num: "<<i+1<<endl;

        //平均灰度值
        avgVal = value / count;
        cout<<"avgVal:"<<avgVal<<endl;

        //比较获取灰度值和标准灰度值
        if(avgVal > standVal)
            cout<<"The result:error"<<endl;
        else
            cout<<"The result:Qualified"<<endl;

        cout<<"=================================="<<endl;
        cout<<endl;
    }

    //判断圆的数量是否正确
    /*if(circles.size() == cirNum)
    {
        cout<<"-------------------"<<endl;
        cout<<"OK"<<endl;
        cout<<"-------------------"<<endl;
    }
    else
    {
        cout<<"-------------------"<<endl;
        cout<<"have problem"<<endl;
        cout<<"-------------------"<<endl;
    }*/

    //显示
    imshow(WIN_SRC, src);
    imshow(WIN_DST, thresPic);
    //imshow("dst", dst);
    waitKey();
    return 0;
}

//回调函数，修改变量值，再把主要流程的工作进行一次
void Callback(int, void*)
{
    int avgVal;
    int value = 0;
    int count = 0;

    src = imread(SRC_PATH);

    cvtColor(src, dst, CV_BGR2GRAY);

    threshold(dst, thresPic, thresValue, 255, CV_THRESH_BINARY);

    GaussianBlur(thresPic, thresPic, Size(9,9), 0, 0);

    findContours(thresPic, contours, info, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);

    for(size_t i = 0; i < contours.size(); i++)
    {
        if(fabs(contourArea(contours[i])) > 2000)
            drawContours(src, contours, i, Scalar(0, 255, 0), 2);
    }

    HoughCircles(thresPic, circles, CV_HOUGH_GRADIENT, 1, 10, param_2, param_1);

    //画出圆心和圆
    for(size_t i = 0; i < circles.size(); i++)
    {
        Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
        int radius = cvRound(circles[i][2]);

        circle(src, center, 1, Scalar(0,255,0), -1);
        circle(src, center, radius, Scalar(0,0,255), 3);

        //定义标准矩形区域
        Point p1(center.x-rectValue, center.y-rectValue);
        Point p2(center.x+rectValue, center.y+rectValue);
        rectangle(src, p1, p2, Scalar(255,255,0), 1);
        //显示数字
        sprintf(buffer, "%d", i+1);
        putText(src, buffer, p2, FONT_HERSHEY_PLAIN, 1, Scalar(255, 0, 0));

        //求得该区域的平均灰度值
        for(int i = p1.x; i < p2.x; i++)
        {
            for(int j = p1.y; j < p2.y; j++)
            {
                value += dst.at<uchar>(j, i);
                count++;
            }
        }

        cout<<"=================================="<<endl;

        //cout<<"center:"<<center<<endl;
        cout<<"Circle-Num: "<<i+1<<endl;

        //平均灰度值
        avgVal = value / count;
        cout<<"avgVal:"<<avgVal<<endl;

        //比较获取灰度值和标准灰度值
        if(avgVal > standVal)
            cout<<"The result:error"<<endl;
        else
            cout<<"The result:Qualified"<<endl;

        cout<<"=================================="<<endl;
    }

    //判断圆的数量是否正确
    /*if(circles.size() == cirNum)
    {
        cout<<"-------------------"<<endl;
        cout<<"OK"<<endl;
        cout<<"-------------------"<<endl;
        cout<<endl;
    }
    else
    {
        cout<<"-------------------"<<endl;
        cout<<"have problem"<<endl;
        cout<<"-------------------"<<endl;
        cout<<endl;
    }*/

    imshow(WIN_SRC, src);
    imshow(WIN_DST, thresPic);
    //imshow("dst", dst);
}
