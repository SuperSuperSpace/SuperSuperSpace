////////////////////////////////////////////////////////////////////////////////
///
///     类名:RestoreImage
///
///     描述:对透视变换图像进行矫正
///
////////////////////////////////////////////////////////////////////////////////

#include "restoreimage.h"

/*Ximpl结构体定义*/
struct RestoreImage::Ximpl
{   
    Mat srcImg, dstImg;
    Mat midImg, edgeDetect;
    Mat afterEnhance;
    vector<Point> resultPointsByEdge;
    vector<Vec4i> lines;

    vector<Point> axisSort(const vector<Vec4i>& lines);                 //线段转换成点集
    vector<Point> pointsFilter(const vector<Point>& candidates);        //对各线段起始点过滤
    vector<Point> findCrossPoint(const vector<Vec4i>& lines);           //根据直线提取确定矩形4个顶点

    void loadImage(Mat imgName);                                        //加载图像
    void doEdgeDetect(int Ct1, int Ct2);                                //边缘提取
    void doAffineTransform(int Cannythreshold1, int Cannythreshold2);   //透视变换
    void dstImageEnhance();                                             //图强增强
};


/*构造函数*/
RestoreImage::RestoreImage() : pImpl(new Ximpl()){}
RestoreImage::RestoreImage(const RestoreImage& other) : pImpl(new Ximpl(*other.pImpl)){}


/*析构函数*/
RestoreImage::~RestoreImage()
{
    delete pImpl;
    pImpl = nullptr;
}


/*操作符重载*/
RestoreImage& RestoreImage::operator =(RestoreImage other)
{
    std::swap(other.pImpl, this->pImpl);
    return *this;
}


/*点集过滤*/
vector<Point> RestoreImage::Ximpl::pointsFilter(const vector<Point> &candidate)
{
    vector<Point> candidates(candidate);
    vector<Point> filter(candidates);
    for(auto i = candidates.begin(); i != candidates.end();)
    {
        for(auto j = filter.begin(); j != filter.end(); ++j)
        {
            if(abs((*i).x - (*j).x) < 5 && abs((*i).y - (*j).y) < 5 && abs((*i).x - (*j).x) > 0 && abs((*i).y - (*j).y) > 0)
                i = filter.erase(i);
            else
                ++i;
        }
    }
    return filter;
}


/*将Vec4i转为Point并排序*/
vector<Point> RestoreImage::Ximpl::axisSort(const vector<Vec4i> &lines)
{
    vector<Point> points(lines.size() * 2);
    for(size_t i = 0; i < lines.size(); ++i)
    {
        points[i * 2].x = lines[i][0];
        points[i * 2].y = lines[i][1];
        points[i * 2 + 1].x = lines[i][2];
        points[i * 2 + 1].y = lines[i][3];
    }
    points = this->pointsFilter(points);
    /*for (auto i : points)
    cout << i.x << " " << i.y << endl;*/
    sort(points.begin(), points.end(), CmpDistanceToZero());
    return points;
}


/*通过直线找点*/
vector<Point> RestoreImage::Ximpl::findCrossPoint(const vector<Vec4i> &lines)
{
    int rightTopFlag = 0;
    int leftDownFlag = 0;
    int diagLength = 0;

    vector<Point> temp = this->axisSort(lines);//直线转换为点集（Vec4i -> Point）并排序

    Point leftTop, rightDown;               //左上，右下点
    vector<Point> rightTop(temp.size());    //右上点集
    vector<Point> leftDown(temp.size());    //左下点集，右上和左下用点集是因为可能有多个点符合

    //对于一般照片，左上和右下是可以直接判断得出的
    leftTop.x = temp[0].x;
    leftTop.y = temp[0].y;
    rightDown.x = temp[temp.size() - 1].x;
    rightDown.y = temp[temp.size() - 1].y;

    //筛选右上和左下点集
    for(auto & i : temp)
        if(i.x > leftTop.x && i.y < rightDown.y)
            rightTop.push_back(i);
    for(auto & i : temp)
        if(i.y > leftTop.y && i.x < rightDown.x)
            leftDown.push_back(i);

    diagLength = (leftTop.x - rightDown.x) * (leftTop.x - rightDown.x) + (leftTop.y - rightDown.y) * (leftTop.y - rightDown.y);
    rightTop.erase(remove(rightTop.begin(), rightTop.end(), Point(0, 0)), rightTop.end());
    leftDown.erase(remove(leftDown.begin(), leftDown.end(), Point(0, 0)), leftDown.end());

    //删除因图像畸变对计算两个距离最长点对的影响的点
    for (auto i = rightTop.begin(); i != rightTop.end();)
    {
        if (((*i).x - leftTop.x) * ((*i).x - leftTop.x) + ((*i).y - leftTop.y) * ((*i).y - leftTop.y) < diagLength / 8)
            i = rightTop.erase(i);
        else
            ++i;
    }

    //算出最长对角线
    int maxDistance = (rightTop[0].x - leftDown[0].x) * (rightTop[0].x - leftDown[0].x) + (rightTop[0].y - leftDown[0].y) * (rightTop[0].y - leftDown[0].y);
    for(size_t i = 0; i < rightTop.size(); ++i)
    {
        for(size_t j = 0; j < leftDown.size(); ++j)
        {
            if ((rightTop[i].x - leftDown[j].x) * (rightTop[i].x - leftDown[j].x) + (rightTop[i].y - leftDown[j].y) * (rightTop[i].y - leftDown[j].y) > maxDistance)
            {
                maxDistance = (rightTop[i].x - leftDown[j].x) * (rightTop[i].x - leftDown[j].x) + (rightTop[i].y - leftDown[j].y) * (rightTop[i].y - leftDown[j].y);
                rightTopFlag = i;
                leftDownFlag = j;
            }
        }
    }
    cout<<leftTop<<endl;
    cout<<rightTop[rightTopFlag]<<endl;
    cout<<leftDown[leftDownFlag]<<endl;
    cout<<rightDown<<endl;
    //通过最长对角线得到左下和右上的点，加上之前得到的左上和右下的两点，此时获取矩形边缘的4个点
    this->resultPointsByEdge.clear();
    this->resultPointsByEdge.push_back(leftTop);
    this->resultPointsByEdge.push_back(rightTop[rightTopFlag]);
    this->resultPointsByEdge.push_back(leftDown[leftDownFlag]);
    this->resultPointsByEdge.push_back(rightDown);

    return this->resultPointsByEdge;
}


/*边缘检测*/
void RestoreImage::Ximpl::doEdgeDetect(int Ct1, int Ct2)
{    
    Canny(this->srcImg, this->midImg, Ct1, Ct2);
    threshold(this->midImg, this->midImg, 128, 255, THRESH_BINARY);
    cvtColor(this->midImg, this->edgeDetect, CV_GRAY2RGB);
    HoughLinesP(this->midImg, this->lines, 1, CV_PI / 180, 100, 200, 250);

    lines.erase(remove_if(lines.begin(), lines.end(), IsCloseToEdge()), lines.end());//去除边缘线段

    for(size_t i = 0; i < this->lines.size(); i++)
    {
        Vec4i l = this->lines[i];
        line(this->edgeDetect, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(80 ,100, 200), 1, CV_AA);
    }

    this->findCrossPoint(this->lines);
    imshow(WINDOW_NAME2, this->edgeDetect);
}


/*仿射变换*/
void RestoreImage::Ximpl::doAffineTransform(int Cannythreshold1, int Cannythreshold2)
{
    this->doEdgeDetect(Cannythreshold1,Cannythreshold2);//仿射变换前先进行边缘，直线提取

    Point2f _srcTriangle[4];
    Point2f _dstTriangle[4];
    vector<Point2f>srcTriangle(_srcTriangle, _srcTriangle + 4);
    vector<Point2f>dstTriangle(_dstTriangle, _dstTriangle + 4);

    //分别取四个顶点坐标平均值
    int leftTopX   = (this->resultPointsByEdge[0].x + this->resultPointsByEdge[0].x) / 2;
    int leftTopY   = (this->resultPointsByEdge[0].y + this->resultPointsByEdge[0].y) / 2;
    int rightTopX  = (this->resultPointsByEdge[1].x + this->resultPointsByEdge[1].x) / 2;
    int rightTopY  = (this->resultPointsByEdge[1].y + this->resultPointsByEdge[1].y) / 2;
    int leftDownX  = (this->resultPointsByEdge[2].x + this->resultPointsByEdge[2].x) / 2;
    int leftDownY  = (this->resultPointsByEdge[2].y + this->resultPointsByEdge[2].y) / 2;
    int rightDownX = (this->resultPointsByEdge[3].x + this->resultPointsByEdge[3].x) / 2;
    int rightDownY = (this->resultPointsByEdge[3].y + this->resultPointsByEdge[3].y) / 2;


    cout<<"The vertex:"<<endl;
    cout<<leftTopX<<" "<<leftTopY<<endl;
    cout<<rightTopX<<" "<<rightTopY<<endl;
    cout<<leftDownX<<" "<<leftDownY<<endl;
    cout<<rightDownX<<" "<<rightDownY<<endl;

    //创建新图存储矫正后的图像
    double newWidth = sqrt((leftTopX - rightTopX) * (leftTopX - rightTopX) + (leftTopY - rightTopY) * (leftTopY - rightTopY));
    double newHeight = sqrt((leftTopX - leftDownX) * (leftTopX - leftDownX) + (leftTopY - leftDownY) * (leftTopY - leftDownY));
    double proportion = 1.2751;
    if(newWidth<newHeight)
        newWidth = newHeight/proportion;
    else
        newHeight = newWidth/proportion;


    this->dstImg = Mat::zeros(newHeight, newWidth, this->srcImg.type());

    srcTriangle[0] = Point2f(leftTopX, leftTopY);
    srcTriangle[1] = Point2f(rightTopX, rightTopY);
    srcTriangle[2] = Point2f(leftDownX, leftDownY);
    srcTriangle[3] = Point2f(rightDownX, rightDownY);

    dstTriangle[0] = Point2f(0, 0);
    dstTriangle[1] = Point2f(newWidth, 0);
    dstTriangle[2] = Point2f(0, newHeight);
    dstTriangle[3] = Point2f(newWidth, newHeight);

    Mat m1 = Mat(srcTriangle);
    Mat m2 = Mat(dstTriangle);
    Mat status;
    Mat h = findHomography(m1, m2, status, 0, 3);
    perspectiveTransform(srcTriangle, dstTriangle, h);
    warpPerspective(this->srcImg, this->dstImg, h, this->dstImg.size());
}


/*图像加强*/
void RestoreImage::Ximpl::dstImageEnhance()
{
    Mat kernel = (Mat_<float>(3, 3) << 0, -1, 0, -1, 5, -1, 0, -1, 0);
    filter2D(this->dstImg, this->afterEnhance, this->dstImg.depth(), kernel);
    //imshow(WINDOW_NAME3, afterEnhance);
}


/*加载图片*/
void RestoreImage::Ximpl::loadImage(Mat imgName)
{
    imgName.copyTo(srcImg);
    if(!srcImg.data)
    {
        cout<<"read the picture error"<<endl;
    }
}


/*矫正并加强图片*/
void RestoreImage::RestoreAndEnhanceImage(Mat imgName, int Cannythreshold1, int Cannythreshold2)
{
    namedWindow(WINDOW_NAME2, 0);
    this->pImpl->loadImage(imgName);
    this->pImpl->doAffineTransform(Cannythreshold1, Cannythreshold2);
    this->pImpl->dstImageEnhance();
    this->pImpl->afterEnhance.copyTo(this->dst);
}


