#ifndef RESTOREIMAGE_H
#define RESTOREIMAGE_H

#include <opencv2/opencv.hpp>
#include <iostream>
#include <cmath>


using namespace std;
using namespace cv;

#define WINDOW_NAME1 "Src_Win"
#define WINDOW_NAME2 "edge"
#define WINDOW_NAME3 "dst"

struct IsCloseToEdge//判断是否接近边缘
{
    bool operator()(Vec4i line)
    {
        return abs(line[0] - line[2]) < 10 || abs(line[1] - line[3]) < 10;
    }
};

struct CmpContoursSize//轮廓大小排序
{
    bool operator()(const vector<Point>& lhs, const vector<Point>& rhs) const
    {
        return lhs.size() > rhs.size();
    }
};

struct CmpDistanceToZero//各个点到原点距离
{
    bool operator()(const Point& lhs, const Point& rhs) const
    {
        return lhs.x + lhs.y < rhs.x + rhs.y;
    }
};

class RestoreImage
{
public:
    RestoreImage();
    RestoreImage(const RestoreImage&);
    RestoreImage& operator=(RestoreImage other);
    ~RestoreImage();
    void RestoreAndEnhanceImage(Mat imgName, int Cannythreshold1, int Cannythreshold2);
    struct Ximpl;
    Ximpl* pImpl;
    Mat dst;

};

#endif
