#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std;
using namespace cv;

//**********************************【全局变量】******************************************
//
//  描述：全局变量定义区域
//
//**************************************************************************************
SearchCircle* g_ptrSerCir;  //全局SearchCircle指针类，该类在"SearchCircle.h"中外部声明



//*****************************【MainWindow类构造函数】************************************
//
//  描述：MainWindow类构造最初所执行的各项工作
//
//**************************************************************************************
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //显示各滚动条数值
    ui->briValueText->setText(QString::number(ui->brightValue->value(), 10));
    ui->conValueText->setText(QString::number(ui->contrastValue->value(), 10));
    ui->Can1ValueText->setText(QString::number(ui->Canny1Value->value(), 10));
    ui->Can2ValueText->setText(QString::number(ui->Canny2Value->value(), 10));

    //禁用指定控件
    ui->brightValue->setEnabled(false);
    ui->contrastValue->setEnabled(false);
    ui->Canny1Value->setEnabled(false);
    ui->Canny2Value->setEnabled(false);
    ui->confirm->setEnabled(false);
    ui->correctBt->setEnabled(false);

    //主界面函数
    mainWin();
}


//*****************************【MainWindow类析构函数】************************************
//
//  描述：MainWindow类销毁所执行的函数
//
//**************************************************************************************
MainWindow::~MainWindow()
{
    delete ui;
}


//**********************************【主界面函数】*****************************************
//
//  描述：创建窗口
//
//**************************************************************************************
void MainWindow::mainWin()
{
    cout<<"Hello,It is Project test"<<endl;
    namedWindow(Win_name, 0);
    namedWindow(Src_name, 0);
}


//********************************【读取图片槽函数】****************************************
//
//  描述：查找按钮槽函数，按下触发弹出查找窗口事件
//
//**************************************************************************************
void MainWindow::on_findpicBt_clicked()
{
    ui->confirm->setEnabled(true);
    ui->imgPath->text().clear();
    QString path = QFileDialog::getOpenFileName(this, tr("Open Image"), ".", tr("Image Files(*.jpg *.png)"));
    ui->imgPath->setText(path);
}


//**********************************【加载槽函数】*****************************************
//
//  描述：加载按钮槽函数，按下触发读取图片事件
//
//**************************************************************************************
void MainWindow::on_confirm_clicked()
{
    //使能滚动条及按钮控件
    ui->brightValue->setEnabled(true);
    ui->contrastValue->setEnabled(true);
    ui->Canny1Value->setEnabled(true);
    ui->Canny2Value->setEnabled(true);
    ui->correctBt->setEnabled(true);

    //禁用查询和加载按钮
    ui->findpicBt->setEnabled(false);
    ui->confirm->setEnabled(false);


    srcImage = imread(ui->imgPath->text().toStdString());//从UI对话框读取原图片
    imshow(Src_name, srcImage);//显示原图片
    PreImg.imgPreProcess(srcImage, ui->brightValue->value(), ui->contrastValue->value());//图像预处理
    restoreClass.RestoreAndEnhanceImage(PreImg.Pic, ui->Canny1Value->value(), ui->Canny2Value->value());//透视变换矫正

    imshow(Win_name, restoreClass.dst);
}


//*******************************【亮度滚动条槽函数】***************************************
//
//  描述：调节亮度滚动条，滚动触发亮度调节大小事件
//
//**************************************************************************************
void MainWindow::on_brightValue_sliderMoved()
{

    PreImg.imgPreProcess(srcImage, ui->brightValue->value(), ui->contrastValue->value());
    restoreClass.RestoreAndEnhanceImage(PreImg.Pic, ui->Canny1Value->value(), ui->Canny2Value->value());
    imshow(Win_name, restoreClass.dst);
    ui->briValueText->setText(QString::number(ui->brightValue->value(), 10));
}


//*******************************【对比度滚动条槽函数】*************************************
//
//  描述：调节对比度滚动条，滚动触发对比度调节大小事件
//
//**************************************************************************************
void MainWindow::on_contrastValue_sliderMoved()
{
    //预处理和透视变换矫正
    PreImg.imgPreProcess(srcImage, ui->brightValue->value(), ui->contrastValue->value());
    restoreClass.RestoreAndEnhanceImage(PreImg.Pic, ui->Canny1Value->value(), ui->Canny2Value->value());
    imshow(Win_name, restoreClass.dst);
    ui->conValueText->setText(QString::number(ui->contrastValue->value(), 10));
}


//*******************************【Canny1滚动条槽函数】*************************************
//
//  描述：调节Canny算子下限滚动条，滚动触发Canny算子下限调节大小事件
//
//***************************************************************************************
void MainWindow::on_Canny1Value_sliderMoved()
{
    //预处理和透视变换矫正
    PreImg.imgPreProcess(srcImage, ui->brightValue->value(), ui->contrastValue->value());
    restoreClass.RestoreAndEnhanceImage(PreImg.Pic, ui->Canny1Value->value(), ui->Canny2Value->value());
    imshow(Win_name, restoreClass.dst);
    ui->Can1ValueText->setText(QString::number(ui->Canny1Value->value(), 10));
}


//*******************************【Canny2滚动条槽函数】*************************************
//
//  描述：调节Canny算子上限滚动条，滚动触发Canny算子上限调节大小事件
//
//***************************************************************************************
void MainWindow::on_Canny2Value_sliderMoved()
{
    //预处理和透视变换矫正
    PreImg.imgPreProcess(srcImage, ui->brightValue->value(), ui->contrastValue->value());
    restoreClass.RestoreAndEnhanceImage(PreImg.Pic, ui->Canny1Value->value(), ui->Canny2Value->value());
    imshow(Win_name, restoreClass.dst);
    ui->Can2ValueText->setText(QString::number(ui->Canny2Value->value(), 10));
}


//**********************************【确认矫正槽函数】****************************************
//
//  描述：确认矫正按钮槽函数，按下触发确认矫正事件，保存矫正图片，关闭所有当前窗口，并生成新的SearchCircle类
//
//*****************************************************************************************
void MainWindow::on_correctBt_clicked()
{
    destroyAllWindows();                                    //销毁所有opencvGUI窗口
    SearchCircle *serCir = new SearchCircle();              //以堆分配方式创建SearchCircle类
    g_ptrSerCir = serCir;                                   //将该新类赋给全局指针(类)
    g_ptrSerCir->show();                                    //显示UI
    g_ptrSerCir->copySrc(restoreClass.dst);                 //拷贝原图像作为备份使用
    g_ptrSerCir->findCircle(restoreClass.dst, 255, 255);    //使用霍夫圆检测圆接口函数
    imshow(Cir_name, g_ptrSerCir->dst);                     //显示处理后的图片
    this->hide();                                           //隐藏主界面
}
