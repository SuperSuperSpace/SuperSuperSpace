#ifndef SEARCHCIRCLE_H
#define SEARCHCIRCLE_H

#include <QWidget>
#include <opencv2/opencv.hpp>
#include <iostream>

#define SWAP(a, b, t)  do { t = a; a = b; b = t; } while(0)
#define CLIP_RANGE(value, min, max)  ( (value) > (max) ? (max) : (((value) < (min)) ? (min) : (value)) )
#define COLOR_RANGE(value)  CLIP_RANGE(value, 0, 255)

using namespace std;
using namespace cv;

namespace Ui {
class SearchCircle;
}

class SearchCircle : public QWidget
{
    Q_OBJECT

public:
    explicit SearchCircle(QWidget *parent = 0);
    ~SearchCircle();
    int adjust(InputArray src, OutputArray dst, int brightness, int contrast);
    void findCircle(Mat src, int bri, int con);
    void copySrc(Mat img);
    const char* Cir_name = "Circle";



    Mat srcImg;
    Mat dst;


private slots:
    void on_contrastValue_sliderMoved();

    void on_brightValue_sliderMoved();

private:
    Ui::SearchCircle *ui;
};

extern SearchCircle* g_ptrSerCir;
void on_MouseHandle(int event, int x, int y, int flags, void* param);

#endif // SEARCHCIRCLE_H
