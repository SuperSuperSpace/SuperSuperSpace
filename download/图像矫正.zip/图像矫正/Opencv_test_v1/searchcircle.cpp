#include "searchcircle.h"
#include "ui_searchcircle.h"

bool g_bDrawingBox = false;
Rect g_rectangle = Rect(-1, -1, 0, 0);
char str[16] = {0};
int g_iRectNum = 1;

SearchCircle::SearchCircle(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SearchCircle)
{
    ui->setupUi(this);
    ui->briLabelValue->setText(QString::number(ui->brightValue->value(), 10));
    ui->conLabelValue->setText(QString::number(ui->contrastValue->value(), 10));

    namedWindow(Cir_name, 0);

    g_rectangle = Rect(-1, -1, 0, 0);
    g_bDrawingBox = false;

    setMouseCallback(Cir_name, on_MouseHandle, 0);
}

SearchCircle::~SearchCircle()
{
    delete ui;
}

/*鼠标回调函数*/
void on_MouseHandle(int event, int x, int y, int flags, void *param)
{
    switch(event)
    {
        //鼠标移动消息
        case EVENT_MOUSEMOVE:
        {

            if(g_bDrawingBox)
            {
                g_rectangle.width = x - g_rectangle.x;
                g_rectangle.height = y - g_rectangle.y;
            }
        }
        break;

        //左键按下消息
        case EVENT_LBUTTONDOWN:
        {
            g_bDrawingBox = true;
            g_rectangle = Rect(x, y, 0, 0);
        }
        break;

        //左键抬起消息
        case EVENT_LBUTTONUP:
        {
            g_bDrawingBox = false;

            if(g_rectangle.width < 0)
            {
                g_rectangle.x += g_rectangle.width;
                g_rectangle.width *= -1;
            }
            if(g_rectangle.height < 0)
            {
                g_rectangle.y += g_rectangle.height;
                g_rectangle.height *= -1;
            }
            rectangle(g_ptrSerCir->dst, g_rectangle.tl(), g_rectangle.br(), Scalar(150, 150, 150), 2);
            cout<<g_rectangle.tl()<<endl;
            cout<<g_rectangle.br()<<endl;
            sprintf(str, "%d", g_iRectNum);
            putText(g_ptrSerCir->dst, str, g_rectangle.tl(), FONT_HERSHEY_COMPLEX_SMALL, 1, Scalar(190,190,190), 1);
            imshow(g_ptrSerCir->Cir_name, g_ptrSerCir->dst);
            g_iRectNum++;
        }
        break;

    }
}


/*拷贝源图像函数*/
void SearchCircle::copySrc(Mat img)
{
    img.copyTo(srcImg);
}

int SearchCircle::adjust(InputArray src, OutputArray dst, int brightness, int contrast)
{
    Mat input = src.getMat();
    if( input.empty() ) {
        return -1;
    }

    dst.create(src.size(), src.type());
    Mat output = dst.getMat();

    brightness = CLIP_RANGE(brightness, -255, 255);
    contrast = CLIP_RANGE(contrast, -255, 255);

    double B = brightness / 255.;
    double c = contrast / 255. ;
    double k = tan( (45 + 44 * c) / 180 * M_PI );

    Mat lookupTable(1, 256, CV_8U);
    uchar *p = lookupTable.data;
    for (int i = 0; i < 256; i++)
        p[i] = COLOR_RANGE( (i - 127.5 * (1 - B)) * k + 127.5 * (1 + B) );

    LUT(input, lookupTable, output);

    return 0;
}

void SearchCircle::findCircle(Mat src, int bri, int con)
{   
    adjust(src, dst, bri - 255, con - 255);

    //霍夫圆检测
    Mat mid;
    //int R,G,B;
    vector<Vec3f> circles;
    vector<Point2f> vec_cir;
    cvtColor(dst,mid,CV_BGR2GRAY);
    GaussianBlur(mid, mid, Size(19,19), 0, 0);
    HoughCircles(mid, circles,CV_HOUGH_GRADIENT,1,mid.rows/20,50,50,0,0);
    for(size_t i = 0; i < circles.size(); i++)
    {

        Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
        int radius = cvRound(circles[i][2]);

        /*vec_cir.push_back(center);
        cout<<"Point"<<i<<":"<<center<<endl;
        B = dst.at<Vec3b>(vec_cir[i].y,vec_cir[i].x)[0];
        G = dst.at<Vec3b>(vec_cir[i].y,vec_cir[i].x)[1];
        R = dst.at<Vec3b>(vec_cir[i].y,vec_cir[i].x)[2];
        cout<<"B:"<<B<<" ";
        cout<<"G:"<<G<<" ";
        cout<<"R:"<<R<<" "<<endl;
        if( ((B & G & R) >= 0) && ((B & G & R) <= 20) )
            cout<<"zero"<<endl;*/
        circle(dst, center, 3, Scalar(0, 255, 0), -1, 8, 0);
        circle(dst, center, radius, Scalar(155, 50, 255), 1, 8, 0);
    }

}

void SearchCircle::on_contrastValue_sliderMoved()
{
    findCircle(srcImg, ui->brightValue->value(), ui->contrastValue->value());
    ui->conLabelValue->setText(QString::number(ui->contrastValue->value(), 10));
    imshow(Cir_name, g_ptrSerCir->dst);
    g_iRectNum = 0;
}

void SearchCircle::on_brightValue_sliderMoved()
{
    findCircle(srcImg, ui->brightValue->value(), ui->contrastValue->value());
    ui->briLabelValue->setText(QString::number(ui->brightValue->value(), 10));
    imshow(Cir_name, g_ptrSerCir->dst);
    g_iRectNum = 0;
}
