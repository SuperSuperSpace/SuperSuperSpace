#ifndef PREPROCESSING_H
#define PREPROCESSING_H

#include <opencv2/opencv.hpp>
#include <iostream>

#define SWAP(a, b, t)  do { t = a; a = b; b = t; } while(0)
#define CLIP_RANGE(value, min, max)  ( (value) > (max) ? (max) : (((value) < (min)) ? (min) : (value)) )
#define COLOR_RANGE(value)  CLIP_RANGE(value, 0, 255)

using namespace std;
using namespace cv;

class PreProcessing
{
public:
    PreProcessing();

    void imgPreProcess(Mat img,int brightValue, int contrastValue);//图像预处理函数

    int adjustBrightnessContrast(InputArray src, OutputArray dst, int brightness, int contrast);//亮度和对比度调节函数

    Mat Pic;//储存处理后的图片

};

#endif // PREPROCESSING_H
