////////////////////////////////////////////////////////////////////////////////
///
///     类名:PreProcessing
///
///     描述:图像的预处理，包括白平衡校正，对比和亮度的调节
///
////////////////////////////////////////////////////////////////////////////////


#include "preprocessing.h"

PreProcessing::PreProcessing()
{

}

//**************************【adjustBrightnessContrast函数】*****************************
//
//  描述：调节亮度和对比度函数
//
//**************************************************************************************
int PreProcessing::adjustBrightnessContrast(InputArray src, OutputArray dst, int brightness, int contrast)
{
    Mat input = src.getMat();
    if( input.empty() ) {
        return -1;
    }

    dst.create(src.size(), src.type());
    Mat output = dst.getMat();

    brightness = CLIP_RANGE(brightness, -255, 255);
    contrast = CLIP_RANGE(contrast, -255, 255);

    double B = brightness / 255.;
    double c = contrast / 255. ;
    double k = tan( (45 + 44 * c) / 180 * M_PI );

    Mat lookupTable(1, 256, CV_8U);
    uchar *p = lookupTable.data;
    for (int i = 0; i < 256; i++)
        p[i] = COLOR_RANGE( (i - 127.5 * (1 - B)) * k + 127.5 * (1 + B) );

    LUT(input, lookupTable, output);

    return 0;
}


//******************************【imgPreProcess函数】************************************
//
//  描述：图像预处理函数接口
//
//**************************************************************************************
void PreProcessing::imgPreProcess(Mat img, int brightValue, int contrastValue)
{

    /**********基于灰度世界算法的白平衡************/

    vector<Mat> imageRGB;
    split(img,imageRGB);                //分离通道
    double R1,G1,B1;
    B1 = mean(imageRGB[0])[0];          //对每个通道取均值
    G1 = mean(imageRGB[1])[0];
    R1 = mean(imageRGB[2])[0];

    double KR,KG,KB;
    KB = (R1 + G1 + B1) / (3 * B1);     //计算各通道增益
    KG = (R1 + G1 + B1) / (3 * G1);
    KR = (R1 + G1 + B1) / (3 * R1);

    imageRGB[0] = imageRGB[0] * KB;     //根据Von Kries对角模型，计算每个像素
    imageRGB[1] = imageRGB[1] * KG;
    imageRGB[2] = imageRGB[2] * KR;

    merge(imageRGB,img);                //三通道合并


    adjustBrightnessContrast(img, Pic, brightValue - 255, contrastValue - 255);      //调用对比度和亮度调节函数
}
