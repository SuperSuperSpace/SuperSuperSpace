#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QDebug>
#include <iostream>
#include <opencv2/opencv.hpp>
#include "restoreimage.h"
#include "preprocessing.h"
#include "searchcircle.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void mainWin();                         //主界面窗口函数

    const char* Win_name = "dst";           //"dst"窗口名称
    const char* Src_name = "src";           //"src"窗口名称
    const char* Cir_name = "Circle";        //"Circle"窗口名称

    cv::Mat srcImage;                       //原图像
    PreProcessing PreImg;                   //图像预处理类
    RestoreImage restoreClass;              //图像矫正类
private slots:
    void on_confirm_clicked();              //加载按钮槽函数

    void on_brightValue_sliderMoved();      //亮度滚动条槽函数

    void on_contrastValue_sliderMoved();    //对比度滚动条槽函数

    void on_findpicBt_clicked();            //查找按钮槽函数

    void on_Canny1Value_sliderMoved();      //Canny阈值下限滚动条槽函数

    void on_Canny2Value_sliderMoved();      //Canny阈值上限滚动条槽函数

    void on_correctBt_clicked();            //确认矫正按钮槽函数

private:
    Ui::MainWindow *ui;


};

#endif // MAINWINDOW_H
