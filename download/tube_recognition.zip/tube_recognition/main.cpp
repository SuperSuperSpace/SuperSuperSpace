#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

#define SWAP(a, b, t)  do { t = a; a = b; b = t; } while(0)
#define CLIP_RANGE(value, min, max)  ( (value) > (max) ? (max) : (((value) < (min)) ? (min) : (value)) )
#define COLOR_RANGE(value)  CLIP_RANGE(value, 0, 255)

//窗口名称
const char* WIN_SRC = "Src win";
const char* WIN_DST = "Dst win";
const char* WIN_LOCAT = "Locat win";

//图像地址
const char* SRC_PATH = "./pic/1.jpg";

//全局Mat类对象
Mat src;
Mat dst;
Mat locatPic;
Mat dstCopy;

//滚动条初始值
static int ajAvgVal = 60;
static int brightness = 181;
static int contrast = 500;
static int blurSize = 0;
static float tubeNum = 0;
static float errorNum = 0;
static int xValue = 10;
static int yValue = 20;

//轮廓和轮廓信息
vector< vector<Point> > contours;
vector<Vec4i> hire;

//回调函数声明
void Callback(int, void*);

//亮度和对比度调节函数实现
int adjustBrightnessContrast(InputArray src, OutputArray dst, int brightness, int contrast)
{
    Mat input = src.getMat();
    if( input.empty() ) {
        return -1;
    }
    dst.create(src.size(), src.type());
    Mat output = dst.getMat();

    brightness = CLIP_RANGE(brightness, -255, 255);
    contrast = CLIP_RANGE(contrast, -255, 255);

    /**
    Algorithm of Brightness Contrast transformation
    The formula is:
        y = [x - 127.5 * (1 - B)] * k + 127.5 * (1 + B);

        x is the input pixel value
        y is the output pixel value
        B is brightness, value range is [-1,1]
        k is used to adjust contrast
            k = tan( (45 + 44 * c) / 180 * PI );
            c is contrast, value range is [-1,1]
    */

    double B = brightness / 255.;
    double c = contrast / 255. ;
    double k = tan( (45 + 44 * c) / 180 * M_PI );

    Mat lookupTable(1, 256, CV_8U);
    uchar *p = lookupTable.data;
    for (int i = 0; i < 256; i++)
        p[i] = COLOR_RANGE( (i - 127.5 * (1 - B)) * k + 127.5 * (1 + B) );

    LUT(input, lookupTable, output);

    return 0;
}

int main()
{
    //载入原图
    src = imread(SRC_PATH);

    //创建窗口
    namedWindow(WIN_LOCAT, 0);
    namedWindow(WIN_SRC, 0);
    namedWindow(WIN_DST, 0);

    //创建进度条
    createTrackbar("brightness:", WIN_DST, &brightness, 500, Callback);
    createTrackbar("contrast:", WIN_DST, &contrast, 500, Callback);
    createTrackbar("ajAvgVal:", WIN_DST, &ajAvgVal, 255, Callback);
    createTrackbar("blurSize:", WIN_DST, &blurSize, 20, Callback);
    createTrackbar("X:", WIN_DST, &xValue, 50, Callback);
    createTrackbar("Y:", WIN_DST, &yValue, 100, Callback);

    //显示
    imshow(WIN_SRC, src);

    //将原图转换为灰度图
    cvtColor(src, dst, CV_BGR2GRAY);

    //亮度和对比度调节
    adjustBrightnessContrast(dst, dst, brightness - 255, contrast - 255);

    //显示
    imshow(WIN_DST, dst);
    imshow(WIN_SRC, src);

    //等待任何按键
    waitKey();

    return 0;
}

//回调函数实现
void Callback(int, void*)
{
    //中断清屏
    system("cls");
    //重新读取原图像
    src = imread(SRC_PATH);
    //拷贝原图像
    src.copyTo(locatPic);

    //初始化试管数量
    tubeNum = 0;
    //初始化错误试管数量
    errorNum = 0;

    //用于计算中间的平均像素值
    float value = 0;
    int count = 0;
    float avgVal = 0;

    //用于计算右边的平均像素值
    float rValue = 0;
    int rCount = 0;
    float rAvgVal = 0;

    //用于计算左边的平均像素值
    float lValue = 0;
    int lCount = 0;
    float lAvgVal = 0;

    //高斯滤波，已取消，需要自己添加
    /*if(blurFlag)
    {
        if(blurSize % 2 == 0)
            GaussianBlur(src, src, Size(blurSize + 1, blurSize + 1), 0);
        else
            GaussianBlur(src, src, Size(blurSize, blurSize), 0);
    }*/

    //转化灰度图
    cvtColor(src, dst, CV_BGR2GRAY);

    //调节对比度和亮度
    adjustBrightnessContrast(dst, dst, brightness - 255, contrast - 255);
    adjustBrightnessContrast(src, src, brightness - 255, contrast - 255);

    //寻找轮廓
    findContours(dst, contours, hire, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

    //拷贝dst图像
    dst.copyTo(dstCopy);

    //膨胀操作，加强图像中的高亮区域
    Mat element;
    if(blurSize % 2 == 0)
        element = getStructuringElement(MORPH_RECT, Size(blurSize + 1, blurSize + 1));
    else
        element = getStructuringElement(MORPH_RECT, Size(blurSize, blurSize));
    dilate(dst, dst, element);

    //寻找轮廓凸包
    vector< vector<Point> > hull(contours.size());
    for(size_t i = 0; i < contours.size(); i++)
    {
        convexHull(Mat(contours[i]), hull[i], false);
    }

    //基于轮廓的试管缺陷判断操作
    for(size_t i = 0; i < contours.size(); i++)
    {
        //剔除不符合试管面积的轮廓
        if(fabs(contourArea(contours[i])) > 5500 && fabs(contourArea(contours[i])) < 12000)
        {
            cout<<"------------------------"<<endl;

            tubeNum++;
            drawContours(src, hull, i, Scalar(0,255,0), 2);
            //得到轮廓凸包点集的构成的矩形
            Rect boundingBox = boundingRect(hull[i]);
            //rectangle(locatPic, boundingBox, Scalar(0, 255, 255), 2);

            //根据这个矩形长度来剔除短试管
            if(boundingBox.height < 650)
            {
                putText(locatPic, "err", boundingBox.tl(), FONT_HERSHEY_PLAIN, 2, Scalar(255, 255, 255), 2);
                errorNum++;
            }

            //中间区域缺陷检测，使用的办法是计算试管口附近区域的像素值，下边的双边检测方法和此类似
            for(int i = boundingBox.tl().x; i < boundingBox.br().x; i++)
            {
                for(int j = boundingBox.tl().y; j < boundingBox.tl().y + 50; j++)
                {
                    value += dst.at<uchar>(j, i);
                    count++;
                }
            }
            avgVal = value / count;
            cout<<"c:"<<avgVal<<endl;
            if(avgVal < ajAvgVal)
            {
                putText(locatPic, "err", boundingBox.tl(), FONT_HERSHEY_PLAIN, 1, Scalar(255, 255, 255), 1);
                errorNum++;
            }

            //右边区域缺陷检测
            for(int i = boundingBox.br().x; i > boundingBox.br().x - xValue; i--)
            {
                for(int j = boundingBox.tl().y; j < boundingBox.tl().y + yValue; j++)
                {

                    /*if(dstCopy.at<uchar>(j, i) > 250 || dstCopy.at<uchar>(j, i) < 10)
                        continue;*/
                    rValue += dstCopy.at<uchar>(j, i);
                    rCount++;
                }
            }
            rAvgVal = rValue / rCount;
            cout<<"r:"<<rAvgVal<<endl;
            if(rAvgVal < 40)
            {
                putText(locatPic, "Rerr", boundingBox.tl(), FONT_HERSHEY_PLAIN, 1, Scalar(255, 255, 255), 1);
                errorNum++;
            }

            //左边区域缺陷检测
            for(int i = boundingBox.tl().x; i < boundingBox.tl().x + xValue; i++)
            {
                for(int j = boundingBox.tl().y; j < boundingBox.tl().y + yValue; j++)
                {

                    /*if(dstCopy.at<uchar>(j, i) > 250 || dstCopy.at<uchar>(j, i) < 10)
                        continue;*/
                    lValue += dstCopy.at<uchar>(j, i);
                    lCount++;
                }
            }
            lAvgVal = lValue / lCount;
            cout<<"l:"<<lAvgVal<<endl;
            if(lAvgVal < 50)
            {
                //putText(locatPic, "Lerr", boundingBox.tl(), FONT_HERSHEY_PLAIN, 1, Scalar(255, 255, 255), 1);
                //errorNum++;
            }

            cout<<"------------------------"<<endl;
       }
    }

    //表格制作
    //rectangle(locatPic, Point(520, 2), Point(1070, 1018), Scalar(50, 200, 50), 3);

    rectangle(locatPic, Point(700, 2), Point(780, 1018), Scalar(50, 200, 50), 3);
    putText(locatPic, "1", Point(730, 1018), FONT_HERSHEY_PLAIN, 2, Scalar(255, 255, 255), 3);

    rectangle(locatPic, Point(780, 2), Point(860, 1018), Scalar(50, 200, 50), 3);
    putText(locatPic, "2", Point(810, 1018), FONT_HERSHEY_PLAIN, 2, Scalar(255, 255, 255), 3);

    rectangle(locatPic, Point(860, 2), Point(940, 1018), Scalar(50, 200, 50), 3);
    putText(locatPic, "3", Point(890, 1018), FONT_HERSHEY_PLAIN, 2, Scalar(255, 255, 255), 3);

    //rectangle(locatPic, Point(940, 2), Point(1020, 1018), Scalar(50, 200, 50), 3);
    //putText(locatPic, "4", Point(970, 1018), FONT_HERSHEY_PLAIN, 2, Scalar(255, 255, 255), 3);

    //保存
    Mat tube_1 = locatPic(Rect(Point(620, 2), Point(700, 1018)));
    imwrite("./tubePic/tube_1.jpg", tube_1);
    Mat tube_2 = locatPic(Rect(Point(700, 2), Point(780, 1018)));
    imwrite("./tubePic/tube_2.jpg", tube_2);
    Mat tube_3 = locatPic(Rect(Point(780, 2), Point(860, 1018)));
    imwrite("./tubePic/tube_3.jpg", tube_3);
    Mat tube_4 = locatPic(Rect(Point(860, 2), Point(940, 1018)));
    imwrite("./tubePic/tube_4.jpg", tube_4);


    //在终端输出合格率和试管数
    cout<<"==============================="<<endl;
    cout<<"The Qualification rate: "<<((tubeNum - errorNum) / tubeNum) * 100<<"%"<<endl;
    cout<<"Error num:"<<errorNum<<endl;
    cout<<"==============================="<<endl;

    //显示图像
    imshow(WIN_DST, dst);
    imshow(WIN_SRC, src);
    imshow(WIN_LOCAT, locatPic);
}
